import re
from datetime import datetime

D = r"(\d{1,2}[/\-.]\d{1,2}[/\-.]\d{2,4})"
NUM = r"([\d,]+(?:\.\d+)?)"
# Consumer numbers are often printed with spaces ("41205 06789"). The first token must contain a digit,
# so words such as "Category" or "Name" after the label are not picked up.
CONSUMER = r"((?=[A-Z0-9\-]*\d)[A-Z0-9\-]{3,18}(?: \d{2,6}){0,3})"
PATTERNS = {
    "consumer_number": rf"(?:consumer|account|connection|service)\s*(?:no|number|#)?\b[\s.:\-]*{CONSUMER}",
    "units": rf"(?:units?\s*consumed|total\s*units?|billed\s*units?|kwh\s*consumed|energy\s*consumed|net\s*consumption)[^\d]{{0,20}}{NUM}",
    "amount": rf"(?:total\s*(?:bill\s*)?amount|net\s*(?:bill\s*)?(?:amount\s*)?payable|amount\s*payable|total\s*payable|bill\s*amount)[^\d]{{0,20}}{NUM}",
    "tariff": r"tariff(?:\s*category)?[\s:\-]*([A-Za-z0-9 \-/]{2,30})",
    "rate": r"(?:energy\s*charge|rate)[^\d]{0,15}(\d+\.\d{1,2})",
    "billing_date": rf"(?:bill\s*date|billing\s*date|date\s*of\s*bill)[\s:\-]*{D}",
    "period": rf"{D}\s*(?:to|-|–)\s*{D}",
}
FIELDS = ("consumer_number", "billing_date", "period_start", "period_end",
          "days", "units", "amount", "tariff", "rate")


def _date(s: str):
    for fmt in ("%d/%m/%Y", "%d-%m-%Y", "%d.%m.%Y", "%d/%m/%y", "%d-%m-%y"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    return None


def _find(key: str, text: str):
    return re.search(PATTERNS[key], text, re.IGNORECASE)


def _confidence(out: dict) -> float:
    found = sum(out[k] is not None for k in ("units", "amount", "consumer_number", "billing_date"))
    return round(found / 4, 2)


def parse_bill(text: str) -> dict:
    out: dict = {k: None for k in FIELDS}
    for key in ("billing_date", "tariff"):
        m = _find(key, text)
        out[key] = m.group(1).strip() if m else None
    for m in re.finditer(PATTERNS["consumer_number"], text, re.IGNORECASE):
        number = m.group(1).replace(" ", "")
        if len(number) >= 5:
            out["consumer_number"] = number
            break
    for key in ("units", "amount", "rate"):
        m = _find(key, text)
        try:
            out[key] = float(m.group(1).replace(",", "")) if m else None
        except ValueError:  # e.g. a stray "," picked up by OCR
            out[key] = None
    m = _find("period", text)
    if m:
        a, b = _date(m.group(1)), _date(m.group(2))
        out["period_start"], out["period_end"] = m.group(1), m.group(2)
        if a and b and b > a:
            out["days"] = (b - a).days
    if out["rate"] is None and out["units"] and out["amount"]:
        out["rate"] = round(out["amount"] / out["units"], 2)
    out["confidence"] = _confidence(out)
    return out


def merge(a: dict, b: dict) -> dict:
    """Fill the gaps of `a` with values found in `b`."""
    out = {k: a[k] if a[k] is not None else b[k] for k in FIELDS}
    out["confidence"] = _confidence(out)
    return out
