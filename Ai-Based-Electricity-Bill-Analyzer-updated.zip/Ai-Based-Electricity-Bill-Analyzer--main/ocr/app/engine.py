import io
import time
from collections.abc import Iterator

import cv2
import numpy as np
import pytesseract
from pdf2image import convert_from_bytes
from PIL import Image, ImageOps

Image.MAX_IMAGE_PIXELS = 60_000_000  # reject decompression bombs
TARGET_SIDE = 2000  # long side in pixels: big enough for small print, small enough to be fast
OCR_TIMEOUT = 60  # seconds per OCR pass
TIME_BUDGET = 70  # don't start a retry pass after this many seconds (slow free-tier CPUs)


def _load_pages(data: bytes, filename: str) -> list[np.ndarray]:
    if filename.lower().endswith(".pdf"):
        pages = convert_from_bytes(data, dpi=200, first_page=1, last_page=3)
        return [np.array(p.convert("RGB")) for p in pages]
    img = ImageOps.exif_transpose(Image.open(io.BytesIO(data)))  # phone photos carry a rotation tag
    return [np.array(img.convert("RGB"))]


def _gray(rgb: np.ndarray) -> np.ndarray:
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    scale = min(max(TARGET_SIDE / max(gray.shape), 0.2), 2.0)
    if abs(scale - 1) > 0.05:
        interp = cv2.INTER_AREA if scale < 1 else cv2.INTER_CUBIC
        gray = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=interp)
    return gray


def _binarise(gray: np.ndarray) -> np.ndarray:
    gray = cv2.medianBlur(gray, 3)
    return cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]


def _ocr(img: np.ndarray) -> str:
    return pytesseract.image_to_string(img, config="--psm 6", timeout=OCR_TIMEOUT)


def extract_texts(data: bytes, filename: str) -> Iterator[str]:
    """Yield OCR text, cheapest strategy first. The caller stops once it has enough."""
    started = time.monotonic()
    grays = [_gray(p) for p in _load_pages(data, filename)]
    yield "\n".join(_ocr(g) for g in grays)
    if time.monotonic() - started < TIME_BUDGET:
        yield "\n".join(_ocr(_binarise(g)) for g in grays)


def extract_text(data: bytes, filename: str) -> str:
    return next(extract_texts(data, filename))
