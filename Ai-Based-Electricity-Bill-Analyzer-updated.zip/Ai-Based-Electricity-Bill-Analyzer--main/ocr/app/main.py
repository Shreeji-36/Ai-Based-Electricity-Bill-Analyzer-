from fastapi import FastAPI, File, HTTPException, UploadFile
from app.engine import extract_texts
from app.extractor import merge, parse_bill

ALLOWED = (".jpg", ".jpeg", ".png", ".pdf")
MAX_BYTES = 8 * 1024 * 1024

app = FastAPI(title="OCR Service")


@app.get("/health")
def health():
    return {"status": "ok"}


# A plain `def` (not `async def`) so FastAPI runs the slow OCR in a worker thread and the
# server keeps answering /health while a bill is being read.
@app.post("/extract")
def extract(file: UploadFile = File(...)):
    name = (file.filename or "").lower()
    if not name.endswith(ALLOWED):
        raise HTTPException(415, "Only JPG, JPEG, PNG or PDF files are supported")
    data = file.file.read(MAX_BYTES + 1)
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "File too large (max 8 MB)")

    best = None
    try:
        for text in extract_texts(data, name):  # plain pass first, then a binarised retry
            parsed = parse_bill(text)
            best = parsed if best is None else merge(best, parsed)
            if best["units"] is not None and best["amount"] is not None:
                break
    except Exception:
        if best is None:
            raise HTTPException(422, "Could not read this file. Please enter the values manually.")
    if best is None or best["confidence"] == 0:
        raise HTTPException(422, "No bill values found in this file. Please enter them manually "
                                 "or upload a clearer, straight-on photo or PDF.")
    return best
