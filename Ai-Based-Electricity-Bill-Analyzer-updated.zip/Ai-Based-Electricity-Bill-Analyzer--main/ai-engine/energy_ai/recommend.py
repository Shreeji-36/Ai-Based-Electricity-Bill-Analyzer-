"""Pick machine-specific recommendations from the catalog."""
from energy_ai.catalog import GENERIC, KINDS, OTHERS

MAX_SAVING = 0.25  # one machine's actions never claim more than 25% of its consumption


def _kind(name: str) -> dict:
    n = name.lower()
    for kind in KINDS:
        if any(word in n for word in kind["match"]):
            return kind
    return GENERIC


def _applies(when: dict, ctx: dict) -> bool:
    return (ctx["qty"] >= when.get("min_qty", 0)
            and ctx["hours"] >= when.get("min_hours", 0)
            and ctx["hours"] <= when.get("max_hours", 24)
            and ctx["eff"] <= when.get("max_eff", 100)
            and ctx["pct"] >= when.get("min_pct", 0))


def _text(template: str, ctx: dict) -> str:
    return template.format(qty=ctx["qty"], hours=f"{ctx['hours']:g}")


def _pick(actions: list[dict], ctx: dict, limit: int) -> list[dict]:
    """Best action per category; the best Maintenance action always comes first."""
    usable = sorted((a for a in actions if _applies(a["when"], ctx)),
                    key=lambda a: a["frac"], reverse=True)
    maint = next((a for a in usable if a["cat"] == "Maintenance"), None)
    picked = [maint] if maint else []
    used = {"Maintenance"} if maint else set()
    for a in usable:
        if len(picked) >= limit:
            break
        if a["cat"] not in used:
            picked.append(a)
            used.add(a["cat"])
    return picked


def recommendations(rows: list[dict], rate: float, machine_flags: list[dict] | None = None) -> list[dict]:
    flagged = {f["machine"] for f in machine_flags or []}
    groups = []
    for r in rows:
        if r["units"] <= 0:
            continue
        ctx = {"qty": int(r.get("qty") or 1), "hours": float(r.get("hours") or 0),
               "eff": r["efficiency"], "pct": r["pct"]}
        if r["name"] == "Others":
            picked, priority = _pick(OTHERS, ctx, 2), "Low"
            boost = 1.0
        else:
            high = r["pct"] >= 20 or r["efficiency"] < 75 or r["name"] in flagged
            mid = r["pct"] >= 10 or r["efficiency"] < 80
            priority, limit = ("High", 3) if high else ("Medium", 2) if mid else ("Low", 1)
            picked = _pick(_kind(r["name"])["actions"], ctx, limit)
            boost = 1 + max(0, 80 - r["efficiency"]) / 100  # less efficient = more to gain
        if not picked:
            continue
        fracs = [a["frac"] * boost for a in picked]
        scale = min(1.0, MAX_SAVING / sum(fracs))
        items = []
        for a, f in zip(picked, fracs):
            s = round(r["units"] * f * scale)
            items.append({"machine": r["name"], "category": a["cat"], "priority": priority,
                          "text": _text(a["text"], ctx), "save_units": s,
                          "save_cost": round(s * rate)})
        groups.append(sorted(items, key=lambda x: x["save_cost"], reverse=True))
    groups.sort(key=lambda g: sum(i["save_cost"] for i in g), reverse=True)
    return [item for g in groups for item in g]
