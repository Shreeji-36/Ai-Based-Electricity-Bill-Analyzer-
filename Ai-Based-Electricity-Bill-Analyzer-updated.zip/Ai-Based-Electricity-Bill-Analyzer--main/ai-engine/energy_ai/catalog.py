"""Machine-specific energy-saving actions.

Each machine "kind" lists several actions in different categories. The engine in
recommend.py picks the ones that fit a machine's real situation (quantity, hours per
day, efficiency, share of the bill), so different machines get different advice.

`frac` is the typical share of that machine's own consumption the action can save.
These are planning estimates, not guarantees: calibrate them with audit data.

`when` conditions (all optional): min_qty, min_hours, max_hours, max_eff, min_pct.
Text placeholders: {qty} = number of machines, {hours} = running hours/day per machine.
"""


def _a(cat: str, frac: float, text: str, **when) -> dict:
    return {"cat": cat, "frac": frac, "text": text, "when": when}


KINDS = [
    {"id": "chiller", "match": ["chiller"], "actions": [
        _a("Maintenance", 0.06, "Clean the condenser tubes and cooling-tower fill and descale the evaporators. Fouled surfaces make a chiller draw more power for the same cooling."),
        _a("Operations", 0.08, "Run the {qty} chillers in a lead-lag sequence so only as many run as the cooling load needs, each near its efficient part-load point.", min_qty=2),
        _a("Controls", 0.05, "Raise the chilled-water setpoint by 1-2 °C where the process allows, and reset it automatically with the load."),
        _a("Retrofit", 0.07, "Fit variable-speed drives on the chilled-water pumps, condenser-water pumps and cooling-tower fans."),
        _a("Scheduling", 0.06, "Chillers run about {hours} h/day. Pre-cool in off-peak hours and shut units down during non-production periods.", min_hours=14),
        _a("Monitoring", 0.03, "Meter kW per ton on each chiller and investigate any unit that drifts above its baseline.", max_eff=80),
    ]},
    {"id": "hvac", "match": ["hvac"], "actions": [
        _a("Maintenance", 0.05, "Clean or replace air filters and clean the coils and drain pans. Blocked filters and dirty coils raise fan and compressor power."),
        _a("Controls", 0.07, "Widen the temperature and humidity setpoints to the limits the process allows, and add night or unoccupied setbacks."),
        _a("Retrofit", 0.08, "Fit variable-speed drives on air-handling-unit fans and chilled-water pumps, and control them by pressure or return-air conditions."),
        _a("Scheduling", 0.06, "HVAC runs about {hours} h/day. Set back or switch off zones outside production hours, keeping pressure and cleanroom needs in mind.", min_hours=16),
        _a("Operations", 0.04, "Sequence the {qty} HVAC units on demand instead of running them all together.", min_qty=3),
    ]},
    {"id": "air_compressor", "match": ["air compressor"], "actions": [
        _a("Maintenance", 0.08, "Find and fix compressed-air leaks with an ultrasonic detector, and clean the intake filters and coolers. Leaks can waste a large share of compressor output."),
        _a("Controls", 0.07, "Lower the discharge pressure to the minimum your tools really need. Every bar saved cuts compressor power."),
        _a("Operations", 0.08, "Use a sequencer so only the compressors you need are running, with one variable-speed machine as the trim unit. Don't let the {qty} units run unloaded.", min_qty=2),
        _a("Retrofit", 0.06, "Add a variable-speed compressor for the varying load, or a larger air receiver, to reduce unloaded running."),
        _a("Scheduling", 0.05, "Compressors run about {hours} h/day. Switch them off at breaks and shift end, and isolate idle lines with auto-shutoff valves.", min_hours=16),
    ]},
    {"id": "refrigeration_compressor", "match": ["refrigeration compressor"], "actions": [
        _a("Maintenance", 0.07, "Clean the condensers and evaporators and check the refrigerant charge. Fouled coils and low charge force the compressor to work harder."),
        _a("Controls", 0.08, "Use floating head pressure so condensing pressure falls in cooler weather, and switch to on-demand defrost."),
        _a("Operations", 0.08, "Stage the {qty} compressors by load, with one variable-speed unit as trim, rather than running many at low load.", min_qty=2),
        _a("Retrofit", 0.07, "Add variable-speed drives to the compressors and condenser fans."),
        _a("Scheduling", 0.05, "Compressors run about {hours} h/day. Pre-cool in off-peak hours and avoid loading and door-open peaks.", min_hours=18),
        _a("Monitoring", 0.03, "Track suction and discharge pressure and power trends to catch efficiency loss early.", max_eff=78),
    ]},
    {"id": "dryer", "match": ["dryer"], "actions": [
        _a("Maintenance", 0.05, "Clean or replace the air filters, check gaskets and ducts for air leaks, and clean the fan blades."),
        _a("Controls", 0.07, "Stop each batch on outlet-air temperature or moisture end-point instead of a fixed timer, so it isn't over-dried."),
        _a("Retrofit", 0.06, "Recover heat from the exhaust air and fit a variable-speed drive on the blower."),
        _a("Operations", 0.05, "Group batches so the {qty} dryers run full loads back to back rather than partly loaded.", min_qty=2),
        _a("Scheduling", 0.04, "Run batches in off-peak hours where production allows and avoid warming up idle units."),
    ]},
    {"id": "tablet", "match": ["tablet"], "actions": [
        _a("Maintenance", 0.04, "Clean and lubricate punches, dies and the turret on schedule. Worn tooling and friction raise motor load."),
        _a("Operations", 0.06, "Match turret speed and dwell to the product, and don't leave the press running empty between batches."),
        _a("Controls", 0.05, "Switch off the press, dust extraction and booth lighting during changeovers and breaks."),
        _a("Retrofit", 0.05, "Use an IE3/IE4 motor with a variable-speed drive on the main drive."),
        _a("Operations", 0.04, "Plan production so fewer of the {qty} presses run fully loaded instead of many running partly loaded.", min_qty=4),
    ]},
    {"id": "milk_chilling", "match": ["chilling"], "actions": [
        _a("Maintenance", 0.06, "Clean the condenser and evaporator coils, and keep the agitators and tank insulation in good condition."),
        _a("Operations", 0.07, "Use night-time pre-cooling or an ice bank to cut daytime load, and don't chill below the temperature the milk needs."),
        _a("Controls", 0.06, "Set the chilling target only as low as needed and use a tighter thermostat differential to avoid over-chilling."),
        _a("Retrofit", 0.06, "Recover condenser heat to pre-heat wash water, and fit variable-speed drives on pumps and agitators."),
        _a("Scheduling", 0.05, "The plant runs about {hours} h/day. Avoid idle running between milk collections.", min_hours=16),
    ]},
    {"id": "pasteurizer", "match": ["pasteurizer"], "actions": [
        _a("Maintenance", 0.05, "Clean the plates regularly to prevent fouling and check the seals and gaskets. Fouled plates need more heat and pump power."),
        _a("Retrofit", 0.09, "Increase heat regeneration in the plate heat exchanger and fit variable-speed drives on the feed pumps."),
        _a("Operations", 0.06, "Run long continuous batches and avoid stop-start operation. Keep CIP and rinse cycles to what hygiene requires."),
        _a("Controls", 0.04, "Control the hot-water temperature tightly to its set point to avoid overheating."),
    ]},
    {"id": "homogenizer", "match": ["homogenizer"], "actions": [
        _a("Maintenance", 0.05, "Check the valve seats, seals and pistons for wear. Worn parts need more pressure and power for the same result."),
        _a("Controls", 0.06, "Use the lowest homogenizing pressure that still meets your product quality targets."),
        _a("Retrofit", 0.06, "Fit a high-efficiency motor with a variable-speed drive and avoid running on bypass."),
        _a("Operations", 0.05, "Switch it off in production gaps instead of letting it recirculate with no product."),
    ]},
    {"id": "boiler", "match": ["boiler"], "actions": [
        _a("Maintenance", 0.07, "Descale the heat-transfer surfaces, clean burners and tubes, and insulate steam lines and valves. Scale and heat loss waste energy."),
        _a("Controls", 0.06, "Tune the air-to-fuel ratio using flue-gas oxygen readings and add blowdown control."),
        _a("Retrofit", 0.07, "Add an economiser or condensate return to recover waste heat, and fit variable-speed drives on feed pumps and fans."),
        _a("Operations", 0.05, "Fire only as many of the {qty} boilers as the steam demand needs, at higher load, and keep the others off.", min_qty=2),
        _a("Scheduling", 0.04, "Boilers run about {hours} h/day. Lower the hold pressure and switch off outside demand periods.", min_hours=16),
    ]},
    {"id": "arc_furnace", "match": ["arc furnace"], "actions": [
        _a("Maintenance", 0.04, "Maintain the electrodes, water-cooled panels and roof, and keep the refractory in good condition. Seal openings to cut heat loss."),
        _a("Operations", 0.07, "Cut power-on-to-tap time with fast charging and minimal door-open time, and don't hold molten metal longer than needed."),
        _a("Controls", 0.06, "Use foamy-slag practice and tune the electrode regulation to reduce arcing losses."),
        _a("Scheduling", 0.06, "Move charging and melting to off-peak tariff hours where the production plan allows."),
        _a("Retrofit", 0.05, "Preheat scrap with waste heat and add power-factor compensation."),
    ]},
    {"id": "induction_furnace", "match": ["induction furnace"], "actions": [
        _a("Maintenance", 0.05, "Check the coil insulation, cooling-water flow and refractory thickness, and clean the cooling circuit. Worn linings reduce efficiency."),
        _a("Operations", 0.07, "Charge clean, dry, dense scrap, keep the furnace full and use the lid to cut melt time and heat loss."),
        _a("Scheduling", 0.06, "Avoid holding metal at temperature through long idle periods. Schedule melts back to back and off-peak."),
        _a("Retrofit", 0.06, "Upgrade to a modern IGBT power supply and recover heat from the cooling water."),
        _a("Operations", 0.04, "Combine heats so the {qty} furnaces aren't running partly full.", min_qty=2),
    ]},
    {"id": "rolling_mill", "match": ["rolling mill"], "actions": [
        _a("Maintenance", 0.04, "Check roll alignment, bearings and lubrication, and replace worn rolls and gearbox oil to cut friction losses."),
        _a("Operations", 0.07, "Cut empty-mill time between billets and plan rolling sequences to reduce size changes."),
        _a("Retrofit", 0.08, "Replace oversized or old motors with IE3/IE4 motors and add variable-speed drives where the load varies."),
        _a("Scheduling", 0.05, "Plan long rolling campaigns in off-peak hours and keep the mill off during gaps."),
        _a("Monitoring", 0.03, "Meter motor kWh per tonne rolled and compare against a baseline to find waste."),
    ]},
    {"id": "cooling_tower_pump", "match": ["tower pump"], "actions": [
        _a("Maintenance", 0.04, "Clean the tower basin, fill and strainers and check the water treatment. Dirty fill raises pumping and fan power."),
        _a("Retrofit", 0.10, "Fit a variable-speed drive and control the pump by return-water temperature or pressure instead of throttling valves."),
        _a("Operations", 0.06, "Run only the pumps the load needs across the {qty} units and keep the rest on standby.", min_qty=2),
        _a("Controls", 0.04, "Trim the impeller or reset the flow so the pump runs near its best-efficiency point."),
    ]},
    {"id": "pump", "match": ["pump"], "actions": [
        _a("Maintenance", 0.04, "Clean the strainers and impellers, check bearings and seals, and fix leaks. Clogging and wear raise power use."),
        _a("Retrofit", 0.10, "Fit a variable-speed drive and replace old motors with IE3/IE4 models. Throttling valves waste energy."),
        _a("Controls", 0.06, "Right-size the pump or trim the impeller so it runs near its best-efficiency point."),
        _a("Operations", 0.05, "Run only the pumps needed across the {qty} units and keep the rest as standby.", min_qty=2),
        _a("Scheduling", 0.04, "Pumps run about {hours} h/day. Switch them off when demand is low or outside production hours.", min_hours=18),
    ]},
    {"id": "evaporator_fan", "match": ["evaporator"], "actions": [
        _a("Maintenance", 0.05, "Clean the evaporator coils and fan blades and keep the defrost drains clear. Frost and dirt block airflow."),
        _a("Retrofit", 0.12, "Replace old fan motors with EC (electronically commutated) fans, which use far less power."),
        _a("Controls", 0.08, "Slow or cycle the fans when the room temperature is satisfied, and use on-demand defrost."),
        _a("Operations", 0.04, "With {qty} fans, group them into zones so fans in empty or lightly loaded rooms can be switched off.", min_qty=10),
    ]},
    {"id": "condenser", "match": ["condenser"], "actions": [
        _a("Maintenance", 0.08, "Clean the condenser coils and tubes regularly. Dirty coils raise head pressure and compressor power."),
        _a("Controls", 0.06, "Use floating head pressure and stage the condenser fans by pressure instead of running all at full speed."),
        _a("Retrofit", 0.06, "Fit variable-speed drives or EC motors on the condenser fans and improve air or water flow."),
        _a("Operations", 0.04, "Keep the air paths of the {qty} condensers clear and avoid hot-air recirculation.", min_qty=2),
        _a("Monitoring", 0.03, "Track the approach temperature (condensing temperature minus ambient) to see when cleaning is due.", max_eff=80),
    ]},
]

GENERIC = {"id": "generic", "match": [], "actions": [
    _a("Maintenance", 0.05, "Clean the machine and lubricate the moving parts, and check belts, bearings and filters on a fixed schedule."),
    _a("Operations", 0.05, "Switch it off or put it on standby when idle instead of letting it run empty."),
    _a("Retrofit", 0.05, "Replace old motors with IE3/IE4 efficiency motors and fit variable-speed drives where the load varies."),
    _a("Monitoring", 0.03, "Sub-meter this machine so you can track its real consumption and verify savings."),
]}

# Recommendations for the "Others" (unlisted loads) row.
OTHERS = [
    _a("Retrofit", 0.15, "Switch lighting to LED and add motion or daylight sensors.", min_pct=10),
    _a("Operations", 0.10, "Switch off office, auxiliary and standby loads outside working hours.", min_pct=10),
]
