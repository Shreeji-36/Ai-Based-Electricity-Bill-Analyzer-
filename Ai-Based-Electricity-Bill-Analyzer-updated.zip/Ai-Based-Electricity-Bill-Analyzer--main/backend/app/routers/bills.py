import os
import httpx
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy import select
from sqlalchemy.orm import Session
from app.database import get_db
from app.deps import require_roles
from app.models import Bill

router = APIRouter(prefix="/api/bills", tags=["bills"])
OCR_URL = os.getenv("OCR_URL", "http://localhost:8001").rstrip("/")
MAX_BYTES = 8 * 1024 * 1024
# A free-tier OCR service may be asleep: allow up to 30 s to connect, 120 s to finish.
OCR_TIMEOUT = httpx.Timeout(120, connect=30)


@router.post("/upload")
async def upload(file: UploadFile = File(...), _=Depends(require_roles("admin", "analyst"))):
    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "File too large (max 8 MB)")
    try:
        async with httpx.AsyncClient(timeout=OCR_TIMEOUT) as client:
            r = await client.post(f"{OCR_URL}/extract",
                                  files={"file": (file.filename, data, file.content_type)})
    except httpx.HTTPError:
        raise HTTPException(503, "The OCR service is not reachable or is still starting up. "
                                 "Wait a minute and try again, or enter the bill values manually.")
    if r.status_code != 200:
        try:
            detail = r.json().get("detail", "OCR failed")
        except ValueError:  # the host answered with a non-JSON page (e.g. while waking up)
            detail = "The OCR service is starting up. Please try again in a minute."
        raise HTTPException(r.status_code if r.status_code < 500 else 503, str(detail))
    return r.json()  # frontend shows these values for the user to confirm or edit


@router.get("")
def history(industry: str, user=Depends(require_roles("admin", "analyst", "viewer")),
            db: Session = Depends(get_db)):
    rows = db.scalars(select(Bill).where(Bill.user_id == user["id"], Bill.industry == industry)
                      .order_by(Bill.created_at.desc()).limit(24)).all()
    return [{"id": b.id, "units": b.units, "amount": b.amount,
             "billing_date": b.billing_date, "created_at": b.created_at} for b in rows]
