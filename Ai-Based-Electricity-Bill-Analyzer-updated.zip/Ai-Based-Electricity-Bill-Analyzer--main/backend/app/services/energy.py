from energy_ai.anomaly import machine_anomalies
from energy_ai.recommend import recommendations

from app.data.industries import INDUSTRIES


def _in(n: float) -> str:
    """Indian digit grouping, e.g. 1026528 -> 10,26,528 (matches the web app)."""
    digits = str(int(round(n)))
    if len(digits) <= 3:
        return digits
    head, tail, parts = digits[:-3], digits[-3:], []
    while len(head) > 2:
        parts.insert(0, head[-2:])
        head = head[:-2]
    if head:
        parts.insert(0, head)
    return ",".join(parts + [tail])


def analyze(industry: str, bill: dict, hours: dict[str, float],
            quantities: dict[str, int] | None = None) -> dict:
    """Split a monthly bill across machines.

    hours      - average running hours per day of EACH machine of that type
    quantities - how many machines of that type are installed (default 1)
    """
    ind = INDUSTRIES[industry]
    quantities = quantities or {}
    units_total, days = bill["units"], bill["days"]
    rate = bill["amount"] / units_total
    warnings: list[str] = []

    rows = []
    for m in ind["machines"]:
        h = hours.get(m["id"], 0)
        qty = quantities.get(m["id"], 1)
        est = m["kw"] * qty * h * days * (m["efficiency"] / 100 + 0.2)
        rows.append({"name": m["name"], "units": est, "efficiency": m["efficiency"],
                     "qty": qty, "hours": h, "kw": m["kw"]})

    estimated = sum(r["units"] for r in rows)
    if estimated > units_total:  # cap at 95% of the real bill
        scale = units_total * 0.95 / estimated
        warnings.append(
            f"The quantities and hours you entered add up to about {_in(estimated)} kWh, "
            f"more than the bill's {_in(units_total)} kWh. Machine figures were scaled down "
            f"by {round((1 - scale) * 100)}% to fit the bill. Please re-check the quantity and "
            f"hours of your largest machines.")
        for r in rows:
            r["units"] *= scale
    elif 0 < estimated < units_total * 0.3:
        warnings.append(
            f"The machines you entered explain only {round(estimated / units_total * 100)}% of the "
            f"bill; the rest is shown as Others. Check that you included every large machine "
            f"and the correct quantities.")

    others = max(units_total - sum(r["units"] for r in rows), 0)
    rows.append({"name": "Others", "units": others, "efficiency": 90, "qty": 0, "hours": 0, "kw": 0})

    for r in rows:
        r["cost"] = round(r["units"] * rate)
        r["pct"] = round(r["units"] / units_total * 100, 1)
        r["units"] = round(r["units"])
        r["units_each"] = round(r["units"] / r["qty"]) if r["qty"] else 0

    machines = [r for r in rows if r["name"] != "Others"]
    active = [r for r in machines if r["units"] > 0] or machines
    by_units = sorted(active, key=lambda r: r["units"], reverse=True)
    by_eff = sorted(active, key=lambda r: r["efficiency"], reverse=True)

    next_units = round(units_total * 1.03)  # simple placeholder; the AI engine adds the ML forecast
    tips = recommendations(rows, rate, machine_anomalies(rows))

    return {
        "industry": ind["name"],
        "bill": bill,
        "rate": round(rate, 2),
        "rows": rows,
        "highest": by_units[0]["name"],
        "lowest": by_units[-1]["name"],
        "most_efficient": by_eff[0]["name"],
        "least_efficient": by_eff[-1]["name"],
        "forecast": {"units": next_units, "amount": round(next_units * rate)},
        "warnings": warnings,
        "tips": tips,
        "total_savings": sum(t["save_cost"] for t in tips),
    }
