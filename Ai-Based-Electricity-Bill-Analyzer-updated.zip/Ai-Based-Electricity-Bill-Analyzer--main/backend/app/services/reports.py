import csv
import io
from xml.sax.saxutils import escape
from openpyxl import Workbook
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

HEAD = ["Machine", "Quantity", "Hours/day each", "Units (kWh)", "Cost (INR)", "Share (%)", "Efficiency (%)"]


def _row(x: dict) -> list:
    has_qty = x["name"] != "Others"
    return [x["name"], x.get("qty", 1) if has_qty else "-", x.get("hours", "") if has_qty else "-",
            x["units"], x["cost"], x["pct"], x["efficiency"]]


def to_csv(r: dict) -> bytes:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(HEAD)
    for x in r["rows"]:
        w.writerow(_row(x))
    return buf.getvalue().encode()


def to_xlsx(r: dict) -> bytes:
    wb = Workbook()
    ws = wb.active
    ws.title = "Machine Analysis"
    ws.append(HEAD)
    for x in r["rows"]:
        ws.append(_row(x))
    rec = wb.create_sheet("Recommendations")
    rec.append(["Machine", "Type", "Priority", "Recommendation", "Units Saved", "Cost Saved (INR)"])
    for t in r["tips"]:
        rec.append([t["machine"], t["category"], t["priority"], t["text"],
                    t["save_units"], t["save_cost"]])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def to_pdf(r: dict) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4)
    s = getSampleStyleSheet()
    b = r["bill"]
    table = Table([["Machine", "Qty", "Hrs/day", "Units", "Cost", "Share %"]] +
                  [[x["name"], *_row(x)[1:5], x["pct"]] for x in r["rows"]])
    table.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.25, colors.grey),
                               ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey)]))
    items = [
        Paragraph(f"Energy Report - {escape(r['industry'])} Industry", s["Title"]),
        Paragraph(f"Units: {b['units']} | Amount: INR {b['amount']} | Rate: {r['rate']}/unit", s["Normal"]),
        Spacer(1, 12),
        Paragraph("Machine-wise Analysis", s["Heading2"]),
        table,
        Spacer(1, 12),
        Paragraph(f"Forecast next month: {r['forecast']['units']} units / INR {r['forecast']['amount']}", s["Normal"]),
    ]
    for w in r.get("warnings", []):
        items.append(Paragraph(f"Note: {escape(w)}", s["Italic"]))
    items.append(Paragraph("Recommendations", s["Heading2"]))
    for t in r["tips"]:
        items.append(Paragraph(
            f"<b>{escape(t['machine'])}</b> ({escape(t['category'])}, {escape(t['priority'])} priority): "
            f"{escape(t['text'])} Saves about INR {t['save_cost']} per month.", s["Normal"]))
        items.append(Spacer(1, 4))
    items.append(Paragraph(f"Total estimated savings: INR {r['total_savings']}", s["Heading3"]))
    doc.build(items)
    return buf.getvalue()
