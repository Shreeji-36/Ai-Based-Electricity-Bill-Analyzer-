import { Industry } from "./industries";
import { recommend } from "./recommendations";

export type Bill = { units: number; amount: number; days: number };
export type Row = {
  name: string; units: number; cost: number; pct: number; efficiency: number;
  qty: number;   // machines of this type (0 for "Others")
  hours: number; // running hours per day of EACH machine
  units_each: number; // kWh per machine per billing period
};

export function analyze(
  ind: Industry, bill: Bill, hours: Record<string, number>, quantities: Record<string, number> = {},
) {
  const rate = bill.units > 0 ? bill.amount / bill.units : ind.rate;
  const days = bill.days || 30;
  const warnings: string[] = [];

  let rows: Row[] = ind.machines.map((m) => {
    const qty = quantities[m.id] ?? 1;
    const h = hours[m.id] || 0;
    const units = m.kw * qty * h * days * (m.efficiency / 100 + 0.2);
    return { name: m.name, units, cost: 0, pct: 0, efficiency: m.efficiency, qty, hours: h, units_each: 0 };
  });

  const fmt = (n: number) => Math.round(n).toLocaleString("en-IN");
  const est = rows.reduce((s, r) => s + r.units, 0);
  if (est > bill.units) {
    const scale = (bill.units * 0.95) / est;
    warnings.push(
      `The quantities and hours you entered add up to about ${fmt(est)} kWh, more than the bill's ` +
      `${fmt(bill.units)} kWh. Machine figures were scaled down by ${Math.round((1 - scale) * 100)}% ` +
      `to fit the bill. Please re-check the quantity and hours of your largest machines.`);
    rows = rows.map((r) => ({ ...r, units: r.units * scale }));
  } else if (est > 0 && est < bill.units * 0.3) {
    warnings.push(
      `The machines you entered explain only ${Math.round((est / bill.units) * 100)}% of the bill; ` +
      `the rest is shown as Others. Check that you included every large machine and the correct quantities.`);
  }

  const machineTotal = rows.reduce((s, r) => s + r.units, 0);
  rows.push({ name: "Others", units: Math.max(bill.units - machineTotal, 0), cost: 0, pct: 0,
              efficiency: 90, qty: 0, hours: 0, units_each: 0 });

  rows = rows.map((r) => ({
    ...r,
    cost: Math.round(r.units * rate),
    pct: +((r.units / bill.units) * 100).toFixed(1),
    units_each: r.qty ? Math.round(r.units / r.qty) : 0,
    units: Math.round(r.units),
  }));

  const named = rows.filter((r) => r.name !== "Others");
  const active = named.filter((r) => r.units > 0);
  const pool = active.length ? active : named;
  const top = [...pool].sort((a, b) => b.units - a.units)[0];
  const low = [...pool].sort((a, b) => a.units - b.units)[0];
  const best = [...pool].sort((a, b) => b.efficiency - a.efficiency)[0];
  const worst = [...pool].sort((a, b) => a.efficiency - b.efficiency)[0];

  // Simple forecast: +3% trend (the backend AI engine uses a real model)
  const nextUnits = Math.round(bill.units * 1.03);
  const nextBill = Math.round(nextUnits * rate);

  const tips = recommend(rows, rate);

  return { rows, rate, top, low, best, worst, nextUnits, nextBill, tips, warnings,
           totalSavings: tips.reduce((s, t) => s + t.save_cost, 0) };
}
