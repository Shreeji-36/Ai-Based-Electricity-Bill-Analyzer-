// Machine-specific recommendations for demo mode (no backend).
// MIRRORS ai-engine/energy_ai/catalog.py and recommend.py. Keep the two in sync.
import type { Row } from "./energy";

export type Action = {
  cat: string; frac: number; text: string;
  when: { min_qty?: number; min_hours?: number; max_hours?: number; max_eff?: number; min_pct?: number };
};
type Kind = { id: string; match: string[]; actions: Action[] };

export type Recommendation = {
  machine: string; category: string; priority: "High" | "Medium" | "Low";
  text: string; save_units: number; save_cost: number;
};

const KINDS: Kind[] = [
  { id: "chiller", match: ["chiller"], actions: [
      {"cat": "Maintenance", "frac": 0.06, "text": "Clean the condenser tubes and cooling-tower fill and descale the evaporators. Fouled surfaces make a chiller draw more power for the same cooling.", "when": {}},
      {"cat": "Operations", "frac": 0.08, "text": "Run the {qty} chillers in a lead-lag sequence so only as many run as the cooling load needs, each near its efficient part-load point.", "when": {"min_qty": 2}},
      {"cat": "Controls", "frac": 0.05, "text": "Raise the chilled-water setpoint by 1-2 °C where the process allows, and reset it automatically with the load.", "when": {}},
      {"cat": "Retrofit", "frac": 0.07, "text": "Fit variable-speed drives on the chilled-water pumps, condenser-water pumps and cooling-tower fans.", "when": {}},
      {"cat": "Scheduling", "frac": 0.06, "text": "Chillers run about {hours} h/day. Pre-cool in off-peak hours and shut units down during non-production periods.", "when": {"min_hours": 14}},
      {"cat": "Monitoring", "frac": 0.03, "text": "Meter kW per ton on each chiller and investigate any unit that drifts above its baseline.", "when": {"max_eff": 80}},
  ]},
  { id: "hvac", match: ["hvac"], actions: [
      {"cat": "Maintenance", "frac": 0.05, "text": "Clean or replace air filters and clean the coils and drain pans. Blocked filters and dirty coils raise fan and compressor power.", "when": {}},
      {"cat": "Controls", "frac": 0.07, "text": "Widen the temperature and humidity setpoints to the limits the process allows, and add night or unoccupied setbacks.", "when": {}},
      {"cat": "Retrofit", "frac": 0.08, "text": "Fit variable-speed drives on air-handling-unit fans and chilled-water pumps, and control them by pressure or return-air conditions.", "when": {}},
      {"cat": "Scheduling", "frac": 0.06, "text": "HVAC runs about {hours} h/day. Set back or switch off zones outside production hours, keeping pressure and cleanroom needs in mind.", "when": {"min_hours": 16}},
      {"cat": "Operations", "frac": 0.04, "text": "Sequence the {qty} HVAC units on demand instead of running them all together.", "when": {"min_qty": 3}},
  ]},
  { id: "air_compressor", match: ["air compressor"], actions: [
      {"cat": "Maintenance", "frac": 0.08, "text": "Find and fix compressed-air leaks with an ultrasonic detector, and clean the intake filters and coolers. Leaks can waste a large share of compressor output.", "when": {}},
      {"cat": "Controls", "frac": 0.07, "text": "Lower the discharge pressure to the minimum your tools really need. Every bar saved cuts compressor power.", "when": {}},
      {"cat": "Operations", "frac": 0.08, "text": "Use a sequencer so only the compressors you need are running, with one variable-speed machine as the trim unit. Don't let the {qty} units run unloaded.", "when": {"min_qty": 2}},
      {"cat": "Retrofit", "frac": 0.06, "text": "Add a variable-speed compressor for the varying load, or a larger air receiver, to reduce unloaded running.", "when": {}},
      {"cat": "Scheduling", "frac": 0.05, "text": "Compressors run about {hours} h/day. Switch them off at breaks and shift end, and isolate idle lines with auto-shutoff valves.", "when": {"min_hours": 16}},
  ]},
  { id: "refrigeration_compressor", match: ["refrigeration compressor"], actions: [
      {"cat": "Maintenance", "frac": 0.07, "text": "Clean the condensers and evaporators and check the refrigerant charge. Fouled coils and low charge force the compressor to work harder.", "when": {}},
      {"cat": "Controls", "frac": 0.08, "text": "Use floating head pressure so condensing pressure falls in cooler weather, and switch to on-demand defrost.", "when": {}},
      {"cat": "Operations", "frac": 0.08, "text": "Stage the {qty} compressors by load, with one variable-speed unit as trim, rather than running many at low load.", "when": {"min_qty": 2}},
      {"cat": "Retrofit", "frac": 0.07, "text": "Add variable-speed drives to the compressors and condenser fans.", "when": {}},
      {"cat": "Scheduling", "frac": 0.05, "text": "Compressors run about {hours} h/day. Pre-cool in off-peak hours and avoid loading and door-open peaks.", "when": {"min_hours": 18}},
      {"cat": "Monitoring", "frac": 0.03, "text": "Track suction and discharge pressure and power trends to catch efficiency loss early.", "when": {"max_eff": 78}},
  ]},
  { id: "dryer", match: ["dryer"], actions: [
      {"cat": "Maintenance", "frac": 0.05, "text": "Clean or replace the air filters, check gaskets and ducts for air leaks, and clean the fan blades.", "when": {}},
      {"cat": "Controls", "frac": 0.07, "text": "Stop each batch on outlet-air temperature or moisture end-point instead of a fixed timer, so it isn't over-dried.", "when": {}},
      {"cat": "Retrofit", "frac": 0.06, "text": "Recover heat from the exhaust air and fit a variable-speed drive on the blower.", "when": {}},
      {"cat": "Operations", "frac": 0.05, "text": "Group batches so the {qty} dryers run full loads back to back rather than partly loaded.", "when": {"min_qty": 2}},
      {"cat": "Scheduling", "frac": 0.04, "text": "Run batches in off-peak hours where production allows and avoid warming up idle units.", "when": {}},
  ]},
  { id: "tablet", match: ["tablet"], actions: [
      {"cat": "Maintenance", "frac": 0.04, "text": "Clean and lubricate punches, dies and the turret on schedule. Worn tooling and friction raise motor load.", "when": {}},
      {"cat": "Operations", "frac": 0.06, "text": "Match turret speed and dwell to the product, and don't leave the press running empty between batches.", "when": {}},
      {"cat": "Controls", "frac": 0.05, "text": "Switch off the press, dust extraction and booth lighting during changeovers and breaks.", "when": {}},
      {"cat": "Retrofit", "frac": 0.05, "text": "Use an IE3/IE4 motor with a variable-speed drive on the main drive.", "when": {}},
      {"cat": "Operations", "frac": 0.04, "text": "Plan production so fewer of the {qty} presses run fully loaded instead of many running partly loaded.", "when": {"min_qty": 4}},
  ]},
  { id: "milk_chilling", match: ["chilling"], actions: [
      {"cat": "Maintenance", "frac": 0.06, "text": "Clean the condenser and evaporator coils, and keep the agitators and tank insulation in good condition.", "when": {}},
      {"cat": "Operations", "frac": 0.07, "text": "Use night-time pre-cooling or an ice bank to cut daytime load, and don't chill below the temperature the milk needs.", "when": {}},
      {"cat": "Controls", "frac": 0.06, "text": "Set the chilling target only as low as needed and use a tighter thermostat differential to avoid over-chilling.", "when": {}},
      {"cat": "Retrofit", "frac": 0.06, "text": "Recover condenser heat to pre-heat wash water, and fit variable-speed drives on pumps and agitators.", "when": {}},
      {"cat": "Scheduling", "frac": 0.05, "text": "The plant runs about {hours} h/day. Avoid idle running between milk collections.", "when": {"min_hours": 16}},
  ]},
  { id: "pasteurizer", match: ["pasteurizer"], actions: [
      {"cat": "Maintenance", "frac": 0.05, "text": "Clean the plates regularly to prevent fouling and check the seals and gaskets. Fouled plates need more heat and pump power.", "when": {}},
      {"cat": "Retrofit", "frac": 0.09, "text": "Increase heat regeneration in the plate heat exchanger and fit variable-speed drives on the feed pumps.", "when": {}},
      {"cat": "Operations", "frac": 0.06, "text": "Run long continuous batches and avoid stop-start operation. Keep CIP and rinse cycles to what hygiene requires.", "when": {}},
      {"cat": "Controls", "frac": 0.04, "text": "Control the hot-water temperature tightly to its set point to avoid overheating.", "when": {}},
  ]},
  { id: "homogenizer", match: ["homogenizer"], actions: [
      {"cat": "Maintenance", "frac": 0.05, "text": "Check the valve seats, seals and pistons for wear. Worn parts need more pressure and power for the same result.", "when": {}},
      {"cat": "Controls", "frac": 0.06, "text": "Use the lowest homogenizing pressure that still meets your product quality targets.", "when": {}},
      {"cat": "Retrofit", "frac": 0.06, "text": "Fit a high-efficiency motor with a variable-speed drive and avoid running on bypass.", "when": {}},
      {"cat": "Operations", "frac": 0.05, "text": "Switch it off in production gaps instead of letting it recirculate with no product.", "when": {}},
  ]},
  { id: "boiler", match: ["boiler"], actions: [
      {"cat": "Maintenance", "frac": 0.07, "text": "Descale the heat-transfer surfaces, clean burners and tubes, and insulate steam lines and valves. Scale and heat loss waste energy.", "when": {}},
      {"cat": "Controls", "frac": 0.06, "text": "Tune the air-to-fuel ratio using flue-gas oxygen readings and add blowdown control.", "when": {}},
      {"cat": "Retrofit", "frac": 0.07, "text": "Add an economiser or condensate return to recover waste heat, and fit variable-speed drives on feed pumps and fans.", "when": {}},
      {"cat": "Operations", "frac": 0.05, "text": "Fire only as many of the {qty} boilers as the steam demand needs, at higher load, and keep the others off.", "when": {"min_qty": 2}},
      {"cat": "Scheduling", "frac": 0.04, "text": "Boilers run about {hours} h/day. Lower the hold pressure and switch off outside demand periods.", "when": {"min_hours": 16}},
  ]},
  { id: "arc_furnace", match: ["arc furnace"], actions: [
      {"cat": "Maintenance", "frac": 0.04, "text": "Maintain the electrodes, water-cooled panels and roof, and keep the refractory in good condition. Seal openings to cut heat loss.", "when": {}},
      {"cat": "Operations", "frac": 0.07, "text": "Cut power-on-to-tap time with fast charging and minimal door-open time, and don't hold molten metal longer than needed.", "when": {}},
      {"cat": "Controls", "frac": 0.06, "text": "Use foamy-slag practice and tune the electrode regulation to reduce arcing losses.", "when": {}},
      {"cat": "Scheduling", "frac": 0.06, "text": "Move charging and melting to off-peak tariff hours where the production plan allows.", "when": {}},
      {"cat": "Retrofit", "frac": 0.05, "text": "Preheat scrap with waste heat and add power-factor compensation.", "when": {}},
  ]},
  { id: "induction_furnace", match: ["induction furnace"], actions: [
      {"cat": "Maintenance", "frac": 0.05, "text": "Check the coil insulation, cooling-water flow and refractory thickness, and clean the cooling circuit. Worn linings reduce efficiency.", "when": {}},
      {"cat": "Operations", "frac": 0.07, "text": "Charge clean, dry, dense scrap, keep the furnace full and use the lid to cut melt time and heat loss.", "when": {}},
      {"cat": "Scheduling", "frac": 0.06, "text": "Avoid holding metal at temperature through long idle periods. Schedule melts back to back and off-peak.", "when": {}},
      {"cat": "Retrofit", "frac": 0.06, "text": "Upgrade to a modern IGBT power supply and recover heat from the cooling water.", "when": {}},
      {"cat": "Operations", "frac": 0.04, "text": "Combine heats so the {qty} furnaces aren't running partly full.", "when": {"min_qty": 2}},
  ]},
  { id: "rolling_mill", match: ["rolling mill"], actions: [
      {"cat": "Maintenance", "frac": 0.04, "text": "Check roll alignment, bearings and lubrication, and replace worn rolls and gearbox oil to cut friction losses.", "when": {}},
      {"cat": "Operations", "frac": 0.07, "text": "Cut empty-mill time between billets and plan rolling sequences to reduce size changes.", "when": {}},
      {"cat": "Retrofit", "frac": 0.08, "text": "Replace oversized or old motors with IE3/IE4 motors and add variable-speed drives where the load varies.", "when": {}},
      {"cat": "Scheduling", "frac": 0.05, "text": "Plan long rolling campaigns in off-peak hours and keep the mill off during gaps.", "when": {}},
      {"cat": "Monitoring", "frac": 0.03, "text": "Meter motor kWh per tonne rolled and compare against a baseline to find waste.", "when": {}},
  ]},
  { id: "cooling_tower_pump", match: ["tower pump"], actions: [
      {"cat": "Maintenance", "frac": 0.04, "text": "Clean the tower basin, fill and strainers and check the water treatment. Dirty fill raises pumping and fan power.", "when": {}},
      {"cat": "Retrofit", "frac": 0.1, "text": "Fit a variable-speed drive and control the pump by return-water temperature or pressure instead of throttling valves.", "when": {}},
      {"cat": "Operations", "frac": 0.06, "text": "Run only the pumps the load needs across the {qty} units and keep the rest on standby.", "when": {"min_qty": 2}},
      {"cat": "Controls", "frac": 0.04, "text": "Trim the impeller or reset the flow so the pump runs near its best-efficiency point.", "when": {}},
  ]},
  { id: "pump", match: ["pump"], actions: [
      {"cat": "Maintenance", "frac": 0.04, "text": "Clean the strainers and impellers, check bearings and seals, and fix leaks. Clogging and wear raise power use.", "when": {}},
      {"cat": "Retrofit", "frac": 0.1, "text": "Fit a variable-speed drive and replace old motors with IE3/IE4 models. Throttling valves waste energy.", "when": {}},
      {"cat": "Controls", "frac": 0.06, "text": "Right-size the pump or trim the impeller so it runs near its best-efficiency point.", "when": {}},
      {"cat": "Operations", "frac": 0.05, "text": "Run only the pumps needed across the {qty} units and keep the rest as standby.", "when": {"min_qty": 2}},
      {"cat": "Scheduling", "frac": 0.04, "text": "Pumps run about {hours} h/day. Switch them off when demand is low or outside production hours.", "when": {"min_hours": 18}},
  ]},
  { id: "evaporator_fan", match: ["evaporator"], actions: [
      {"cat": "Maintenance", "frac": 0.05, "text": "Clean the evaporator coils and fan blades and keep the defrost drains clear. Frost and dirt block airflow.", "when": {}},
      {"cat": "Retrofit", "frac": 0.12, "text": "Replace old fan motors with EC (electronically commutated) fans, which use far less power.", "when": {}},
      {"cat": "Controls", "frac": 0.08, "text": "Slow or cycle the fans when the room temperature is satisfied, and use on-demand defrost.", "when": {}},
      {"cat": "Operations", "frac": 0.04, "text": "With {qty} fans, group them into zones so fans in empty or lightly loaded rooms can be switched off.", "when": {"min_qty": 10}},
  ]},
  { id: "condenser", match: ["condenser"], actions: [
      {"cat": "Maintenance", "frac": 0.08, "text": "Clean the condenser coils and tubes regularly. Dirty coils raise head pressure and compressor power.", "when": {}},
      {"cat": "Controls", "frac": 0.06, "text": "Use floating head pressure and stage the condenser fans by pressure instead of running all at full speed.", "when": {}},
      {"cat": "Retrofit", "frac": 0.06, "text": "Fit variable-speed drives or EC motors on the condenser fans and improve air or water flow.", "when": {}},
      {"cat": "Operations", "frac": 0.04, "text": "Keep the air paths of the {qty} condensers clear and avoid hot-air recirculation.", "when": {"min_qty": 2}},
      {"cat": "Monitoring", "frac": 0.03, "text": "Track the approach temperature (condensing temperature minus ambient) to see when cleaning is due.", "when": {"max_eff": 80}},
  ]},
];

const GENERIC: Kind = {
  id: "generic", match: [], actions: [
      {"cat": "Maintenance", "frac": 0.05, "text": "Clean the machine and lubricate the moving parts, and check belts, bearings and filters on a fixed schedule.", "when": {}},
      {"cat": "Operations", "frac": 0.05, "text": "Switch it off or put it on standby when idle instead of letting it run empty.", "when": {}},
      {"cat": "Retrofit", "frac": 0.05, "text": "Replace old motors with IE3/IE4 efficiency motors and fit variable-speed drives where the load varies.", "when": {}},
      {"cat": "Monitoring", "frac": 0.03, "text": "Sub-meter this machine so you can track its real consumption and verify savings.", "when": {}},
  ]};

const OTHERS: Action[] = [
  {"cat": "Retrofit", "frac": 0.15, "text": "Switch lighting to LED and add motion or daylight sensors.", "when": {"min_pct": 10}},
  {"cat": "Operations", "frac": 0.1, "text": "Switch off office, auxiliary and standby loads outside working hours.", "when": {"min_pct": 10}},
];

const MAX_SAVING = 0.25;

type Ctx = { qty: number; hours: number; eff: number; pct: number };

function kindOf(name: string): Kind {
  const n = name.toLowerCase();
  return KINDS.find((k) => k.match.some((w) => n.includes(w))) ?? GENERIC;
}

function applies(w: Action["when"], c: Ctx): boolean {
  return c.qty >= (w.min_qty ?? 0) && c.hours >= (w.min_hours ?? 0) && c.hours <= (w.max_hours ?? 24)
    && c.eff <= (w.max_eff ?? 100) && c.pct >= (w.min_pct ?? 0);
}

const fill = (t: string, c: Ctx) =>
  t.replace("{qty}", String(c.qty)).replace("{hours}", String(+c.hours.toFixed(2)));

// Best action per category; the best Maintenance action always comes first.
function pick(actions: Action[], c: Ctx, limit: number): Action[] {
  const usable = actions.filter((a) => applies(a.when, c)).sort((a, b) => b.frac - a.frac);
  const maint = usable.find((a) => a.cat === "Maintenance");
  const picked: Action[] = maint ? [maint] : [];
  const used = new Set<string>(maint ? ["Maintenance"] : []);
  for (const a of usable) {
    if (picked.length >= limit) break;
    if (!used.has(a.cat)) { picked.push(a); used.add(a.cat); }
  }
  return picked;
}

export function recommend(rows: Row[], rate: number): Recommendation[] {
  const groups: Recommendation[][] = [];
  for (const r of rows) {
    if (r.units <= 0) continue;
    const c: Ctx = { qty: Math.max(1, r.qty || 1), hours: r.hours || 0, eff: r.efficiency, pct: r.pct };
    let picked: Action[], priority: Recommendation["priority"], boost = 1;
    if (r.name === "Others") {
      picked = pick(OTHERS, c, 2); priority = "Low";
    } else {
      const high = r.pct >= 20 || r.efficiency < 75;
      const mid = r.pct >= 10 || r.efficiency < 80;
      priority = high ? "High" : mid ? "Medium" : "Low";
      picked = pick(kindOf(r.name).actions, c, high ? 3 : mid ? 2 : 1);
      boost = 1 + Math.max(0, 80 - r.efficiency) / 100;
    }
    if (!picked.length) continue;
    const fracs = picked.map((a) => a.frac * boost);
    const scale = Math.min(1, MAX_SAVING / fracs.reduce((s, f) => s + f, 0));
    const items = picked.map((a, i) => {
      const s = Math.round(r.units * fracs[i] * scale);
      return { machine: r.name, category: a.cat, priority, text: fill(a.text, c),
               save_units: s, save_cost: Math.round(s * rate) };
    });
    groups.push(items.sort((a, b) => b.save_cost - a.save_cost));
  }
  const total = (g: Recommendation[]) => g.reduce((s, i) => s + i.save_cost, 0);
  return groups.sort((a, b) => total(b) - total(a)).flat();
}
