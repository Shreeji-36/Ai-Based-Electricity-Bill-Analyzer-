# Setup Guide

## Option A: Docker (everything)
1. `cp .env.example .env` and edit the values
2. Set `NEXT_PUBLIC_API_URL=http://localhost` in `.env`
3. `docker compose up --build`, then open http://localhost

## Option B: Local development
Backend: `cd backend && pip install -r requirements.txt && pip install -e ../ai-engine && uvicorn app.main:app --reload`
Frontend: `cd frontend && npm install && npm run dev`
OCR: `cd ocr && pip install -r requirements.txt && uvicorn app.main:app --port 8001` (needs Tesseract and Poppler installed)

## Free deployment
- Frontend on Vercel: import the repo, set Root Directory to `frontend`, add `NEXT_PUBLIC_API_URL`.
- Backend on Render (Web Service, Root Directory blank). Build: `pip install -r backend/requirements.txt && pip install ./ai-engine`.
  Start: `cd backend && uvicorn app.main:app --host 0.0.0.0 --port $PORT`. Use a free Neon or Supabase Postgres as `DATABASE_URL`.
- OCR on Render as a second Web Service: Language Docker, Root Directory `ocr`, Dockerfile path `./Dockerfile`,
  Health Check Path `/health`. Then set `OCR_URL` on the backend to its URL (no trailing slash).
- Change `FRONTEND_ORIGIN` on the backend to your Vercel URL.

## Tests
`pip install -r test/requirements.txt && pytest test`