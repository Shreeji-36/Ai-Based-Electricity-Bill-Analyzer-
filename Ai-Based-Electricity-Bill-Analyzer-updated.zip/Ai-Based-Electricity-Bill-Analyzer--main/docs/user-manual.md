# User Manual

1. Register or log in.
2. Choose your industry on the home page.
3. Upload your electricity bill (JPG, PNG or PDF). Check the extracted values and fix any errors.
4. For every machine type, enter **how many machines you have** (Quantity) and the **average hours per day each machine runs**.
   - Example: Chiller Plant, Quantity 50, 10 hours = 50 chillers that each run about 10 hours a day.
   - Leave Quantity empty if you have just one machine. Leave hours empty for machines you do not use.
   - A live check under the list compares your inputs with the bill. "Others" is calculated for you.
5. Open the dashboard: machine-wise units and cost, charts, forecast, anomalies and recommendations.
   The recommendations are specific to each machine type (cleaning, controls, retrofits, scheduling) and take your quantities and running hours into account.
6. Download the report as PDF, Excel or CSV.

If your inputs add up to more than the bill, the dashboard shows a warning and scales the machine figures down to fit the bill.
Re-check the quantity and hours of your biggest machines.

Tip: the more monthly bills you add, the more accurate the forecast and anomaly detection become.
