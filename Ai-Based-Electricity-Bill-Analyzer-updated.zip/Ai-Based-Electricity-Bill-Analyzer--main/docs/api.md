# API Reference

Interactive docs: `/docs` (Swagger) on the running backend.

| Method | Path | Auth | Purpose |
|---|---|---|---|
| POST | /api/auth/register | none | Create account (role: analyst) |
| POST | /api/auth/login | none | Get JWT (form fields: username, password) |
| GET | /api/auth/me | any | Current user |
| GET | /api/industries | none | List industries |
| GET | /api/industries/{id}/machines | none | Machines and default rate |
| POST | /api/bills/upload | admin, analyst | OCR a bill file (jpg/png/pdf, max 8 MB) |
| GET | /api/bills?industry= | any | Bill history |
| POST | /api/analysis | admin, analyst | Run analysis and save it |
| POST | /api/reports/{pdf|xlsx|csv} | any | Download a report |

Send the token as `Authorization: Bearer <token>`.

## Analysis request

`POST /api/analysis` and `POST /api/reports/{fmt}` take the same body:

```json
{
  "industry": "pharmacy",
  "bill": {"units": 900000, "amount": 7650000, "days": 30},
  "hours":      {"chiller": 10, "hvac": 20},
  "quantities": {"chiller": 50, "hvac": 4}
}
```

- `hours`: average running hours per day of **each** machine of that type (0 to 24).
- `quantities`: number of machines of that type (0 to 10,000). Optional; a missing machine counts as 1.

The result contains, per machine row, `qty`, `hours` and `units_each`, plus `warnings` (for example when your inputs exceed the bill)
and `ai.recommendations`, each with `machine`, `category`, `priority`, `text`, `save_units` and `save_cost`.
