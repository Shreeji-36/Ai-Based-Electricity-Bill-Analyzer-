import importlib.util
from pathlib import Path

# The OCR service and the backend both have a package called "app", so load the extractor by path.
_path = Path(__file__).resolve().parent.parent / "ocr" / "app" / "extractor.py"
_spec = importlib.util.spec_from_file_location("ocr_extractor", _path)
_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_mod)
parse_bill, merge = _mod.parse_bill, _mod.merge

SAMPLE = """
Consumer No: GJ1234567
Bill Date: 05/09/2026
Billing Period 05/08/2026 to 04/09/2026
Tariff Category: HT-I Industrial
Total Units Consumed 20,500
Total Amount Payable 1,76,300.00
"""


def test_parse_core_fields():
    r = parse_bill(SAMPLE)
    assert r["consumer_number"] == "GJ1234567"
    assert r["units"] == 20500
    assert r["amount"] == 176300.0
    assert r["days"] == 30
    assert r["confidence"] == 1.0


def test_parse_empty_text():
    assert parse_bill("nothing useful")["confidence"] == 0.0


def test_consumer_number_with_spaces():
    assert parse_bill("Consumer No : 41205 06789")["consumer_number"] == "4120506789"


def test_consumer_words_are_not_numbers():
    text = "Consumer Category Industrial\nConsumer Name Shree Industries\nConsumer No 4120506789"
    assert parse_bill(text)["consumer_number"] == "4120506789"


def test_merge_fills_gaps():
    a = parse_bill("Total Units Consumed 20,500")
    b = parse_bill("Total Amount Payable 1,76,300.00\nConsumer No: GJ1234567")
    m = merge(a, b)
    assert m["units"] == 20500 and m["amount"] == 176300.0 and m["consumer_number"] == "GJ1234567"
