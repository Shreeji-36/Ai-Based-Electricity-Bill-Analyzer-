from energy_ai.anomaly import check_bill
from energy_ai.forecast import forecast_units
from energy_ai.recommend import recommendations


def test_forecast_short_history_is_flat():
    r = forecast_units([1000, 1100], months=2)
    assert r["method"] == "flat" and r["units"] == [1100, 1100]


def test_forecast_trend_goes_up():
    r = forecast_units([1000, 1100, 1200, 1300], months=2)
    assert r["units"][0] > 1300


def test_forecast_never_negative():
    assert min(forecast_units([300, 200, 100, 50], months=3)["units"]) >= 0


def test_anomaly_detected():
    hist = [1000, 1020, 990, 1010, 1005, 995]
    assert check_bill(hist, 2500)["is_anomaly"] is True
    assert check_bill(hist, 1008)["is_anomaly"] is False


def test_anomaly_needs_history():
    assert check_bill([1000], 5000)["method"] == "insufficient-history"

def _row(name, units=10000, pct=20.0, eff=76, qty=1, hours=10):
    return {"name": name, "units": units, "pct": pct, "efficiency": eff, "qty": qty, "hours": hours}


def test_recommendations_differ_per_machine():
    rows = [_row("Chiller Plant"), _row("Air Compressor"), _row("Boiler"),
            _row("Evaporator Fan"), _row("Rolling Mill")]
    recs = recommendations(rows, rate=8.0)
    by_machine = {}
    for r in recs:
        by_machine.setdefault(r["machine"], []).append(r["text"])
    assert set(by_machine) == {r["name"] for r in rows}
    all_text = [t for texts in by_machine.values() for t in texts]
    assert len(set(all_text)) == len(all_text)  # no two recommendations are identical
    assert any("leak" in t.lower() for t in by_machine["Air Compressor"])
    assert any("EC" in t for t in by_machine["Evaporator Fan"])
    assert any("scale" in t.lower() or "descale" in t.lower() for t in by_machine["Boiler"])


def test_every_machine_gets_a_cleaning_or_maintenance_tip():
    recs = recommendations([_row("Fluid Bed Dryer", pct=3, eff=85)], rate=8.0)
    assert recs and recs[0]["category"] == "Maintenance"


def test_quantity_changes_the_advice():
    one = recommendations([_row("Chiller Plant", qty=1)], rate=8.0)
    many = recommendations([_row("Chiller Plant", qty=50)], rate=8.0)
    assert not any("50 chillers" in r["text"] for r in one)
    assert any("50 chillers" in r["text"] for r in many)


def test_savings_are_capped_per_machine():
    rows = [_row("Chiller Plant", units=100000, pct=40, eff=60)]
    saved = sum(r["save_units"] for r in recommendations(rows, rate=8.0))
    assert saved <= 100000 * 0.25 + 3


def test_unused_machine_gets_nothing():
    assert recommendations([_row("Boiler", units=0, pct=0)], rate=8.0) == []


def test_unknown_machine_falls_back_to_generic_advice():
    recs = recommendations([_row("Mystery Machine")], rate=8.0)
    assert recs and all(r["text"] for r in recs)
