import pytest

PAYLOAD = {
    "industry": "pharmacy",
    "bill": {"units": 20000, "amount": 170000, "days": 30},
    "hours": {"hvac": 20, "compressor": 8, "fbd": 6, "tablet": 10, "chiller": 18},
}


def test_health(client):
    assert client.get("/api/health").json() == {"status": "ok"}


def test_register_and_duplicate(client):
    body = {"name": "Test User", "email": "t@test.com", "password": "Password123"}
    assert client.post("/api/auth/register", json=body).status_code == 201
    assert client.post("/api/auth/register", json=body).status_code == 409


def test_login_wrong_password(client):
    r = client.post("/api/auth/login", data={"username": "admin@test.com", "password": "nope"})
    assert r.status_code == 401


def test_analysis_requires_auth(client):
    assert client.post("/api/analysis", json=PAYLOAD).status_code == 401


def test_analysis_totals_match_bill(client, auth):
    r = client.post("/api/analysis", json=PAYLOAD, headers=auth)
    assert r.status_code == 200
    data = r.json()
    assert any(row["name"] == "Others" for row in data["rows"])
    assert abs(sum(row["units"] for row in data["rows"]) - 20000) <= len(data["rows"])
    assert len(data["ai"]["forecast"]["units"]) == 3


def test_invalid_hours_rejected(client, auth):
    bad = {**PAYLOAD, "hours": {"hvac": 30}}
    assert client.post("/api/analysis", json=bad, headers=auth).status_code == 422


def test_reports(client, auth):
    for fmt, ctype in (("csv", "text/csv"), ("xlsx", "spreadsheetml"), ("pdf", "application/pdf")):
        r = client.post(f"/api/reports/{fmt}", json=PAYLOAD, headers=auth)
        assert r.status_code == 200 and ctype in r.headers["content-type"]
        assert len(r.content) > 100

QTY_PAYLOAD = {
    "industry": "pharmacy",
    "bill": {"units": 900000, "amount": 7650000, "days": 30},
    "hours": {"hvac": 20, "compressor": 8, "fbd": 6, "tablet": 10, "chiller": 10},
    "quantities": {"hvac": 4, "compressor": 2, "fbd": 3, "tablet": 6, "chiller": 50},
}


def test_quantities_scale_consumption(client, auth):
    single = client.post("/api/analysis", json={**PAYLOAD, "bill": {"units": 400000, "amount": 3400000, "days": 30}},
                         headers=auth).json()
    ten = client.post("/api/analysis", json={**PAYLOAD, "bill": {"units": 400000, "amount": 3400000, "days": 30},
                                             "quantities": {"hvac": 10}}, headers=auth).json()
    hvac = lambda d: next(r for r in d["rows"] if r["name"] == "HVAC System")
    assert hvac(ten)["qty"] == 10 and hvac(single)["qty"] == 1
    assert hvac(ten)["units"] == pytest.approx(hvac(single)["units"] * 10, rel=0.01)
    assert hvac(ten)["units_each"] == pytest.approx(hvac(single)["units_each"], rel=0.01)


def test_missing_quantities_default_to_one(client, auth):
    data = client.post("/api/analysis", json=PAYLOAD, headers=auth).json()
    assert all(r["qty"] == 1 for r in data["rows"] if r["name"] != "Others")


def test_overshoot_warns_and_still_matches_bill(client, auth):
    data = client.post("/api/analysis", json=QTY_PAYLOAD, headers=auth).json()
    assert data["warnings"] and "scaled down" in data["warnings"][0]
    assert abs(sum(r["units"] for r in data["rows"]) - 900000) <= len(data["rows"])


def test_recommendations_are_machine_specific(client, auth):
    data = client.post("/api/analysis", json=QTY_PAYLOAD, headers=auth).json()
    recs = data["ai"]["recommendations"]
    assert len({r["machine"] for r in recs}) >= 4
    texts = [r["text"] for r in recs]
    assert len(set(texts)) == len(texts)
    assert any("50 chillers" in t for t in texts)
    assert all(r["category"] and r["priority"] for r in recs)


def test_peak_load_uses_quantities(client, auth):
    one = client.post("/api/analysis", json=PAYLOAD, headers=auth).json()["ai"]["peak_load_kw"]
    many = client.post("/api/analysis", json=QTY_PAYLOAD, headers=auth).json()["ai"]["peak_load_kw"]
    assert many > one * 5


def test_invalid_quantity_rejected(client, auth):
    for bad in (-1, 10_001):
        r = client.post("/api/analysis", json={**PAYLOAD, "quantities": {"hvac": bad}}, headers=auth)
        assert r.status_code == 422


def test_reports_include_quantity(client, auth):
    r = client.post("/api/reports/csv", json=QTY_PAYLOAD, headers=auth)
    assert "Quantity" in r.text and ",50," in r.text
