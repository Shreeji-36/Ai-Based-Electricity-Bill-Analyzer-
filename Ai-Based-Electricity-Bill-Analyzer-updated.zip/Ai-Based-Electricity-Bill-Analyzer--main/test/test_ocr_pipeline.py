"""End-to-end OCR check on a generated bill image. Skipped where Tesseract is not installed."""
import importlib.util
import io
import shutil
import sys
from pathlib import Path

import pytest

pytest.importorskip("pytesseract")
pytest.importorskip("cv2")
pytest.importorskip("pdf2image")
if not shutil.which("tesseract"):
    pytest.skip("tesseract binary not installed", allow_module_level=True)

from PIL import Image, ImageDraw, ImageFont  # noqa: E402

OCR_APP = Path(__file__).resolve().parent.parent / "ocr" / "app"
LINES = ["Consumer No : 41205 06789", "Bill Date : 05/09/2026",
         "Billing Period 05/08/2026 to 04/09/2026", "Tariff Category : HT-I Industrial",
         "Total Units Consumed : 20,500", "Total Amount Payable : 1,76,300.00"]


def _load(name):
    spec = importlib.util.spec_from_file_location(f"ocr_{name}", OCR_APP / f"{name}.py")
    mod = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = mod
    spec.loader.exec_module(mod)
    return mod


def _bill_image() -> Image.Image:
    img = Image.new("RGB", (1240, 700), "white")
    draw = ImageDraw.Draw(img)
    try:
        font = ImageFont.truetype("DejaVuSans.ttf", 28)
    except OSError:
        pytest.skip("DejaVuSans font not available")
    for i, line in enumerate(LINES):
        draw.text((50, 40 + i * 70), line, fill="black", font=font)
    return img


@pytest.fixture(scope="module")
def modules():
    return _load("engine"), _load("extractor")


def _read(modules, data, name):
    engine, extractor = modules
    best = None
    for text in engine.extract_texts(data, name):
        parsed = extractor.parse_bill(text)
        best = parsed if best is None else extractor.merge(best, parsed)
        if best["units"] is not None and best["amount"] is not None:
            break
    return best


def test_png(modules):
    buf = io.BytesIO()
    _bill_image().save(buf, "PNG")
    r = _read(modules, buf.getvalue(), "bill.png")
    assert r["units"] == 20500 and r["amount"] == 176300.0
    assert r["consumer_number"] == "4120506789" and r["days"] == 30


def test_phone_photo_with_rotation_tag(modules):
    img = _bill_image().rotate(90, expand=True)  # stored sideways, as phones do
    exif = Image.Exif()
    exif[0x0112] = 6  # "rotate 90 degrees clockwise to display"
    buf = io.BytesIO()
    img.save(buf, "JPEG", exif=exif)
    r = _read(modules, buf.getvalue(), "phone.jpg")
    assert r["units"] == 20500 and r["amount"] == 176300.0


def test_pdf(modules):
    buf = io.BytesIO()
    _bill_image().save(buf, "PDF")
    r = _read(modules, buf.getvalue(), "bill.pdf")
    assert r["units"] == 20500 and r["amount"] == 176300.0
